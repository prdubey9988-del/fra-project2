"""
FRA Group Project 2 — Stock Price Data Fetcher
Pulls historical stock prices for ICICI Bank, Yes Bank, and all peers
from Yahoo Finance and exports to JavaScript data file.
"""

import yfinance as yf
import json
from datetime import datetime

# Define tickers (NSE)
TICKERS = {
    # ICICI Bank + Peers
    "ICICI Bank": "ICICIBANK.NS",
    "HDFC Bank": "HDFCBANK.NS",
    "Axis Bank": "AXISBANK.NS",
    "Kotak Mahindra Bank": "KOTAKBANK.NS",
    # Yes Bank + Peers
    "Yes Bank": "YESBANK.NS",
    "Federal Bank": "FEDERALBNK.NS",
    "RBL Bank": "RBLBANK.NS",
    "IDFC First Bank": "IDFCFIRSTB.NS",
    "Bandhan Bank": "BANDHANBNK.NS",
    # Benchmark
    "Nifty Bank": "^NSEBANK",
}

START_DATE = "2014-04-01"
END_DATE = "2024-03-31"

def fetch_monthly_data():
    """Fetch monthly closing prices for all tickers."""
    all_data = {}
    
    for name, ticker in TICKERS.items():
        print(f"Fetching {name} ({ticker})...")
        try:
            stock = yf.Ticker(ticker)
            hist = stock.history(start=START_DATE, end=END_DATE, interval="1mo")
            
            if hist.empty:
                print(f"  WARNING: No data for {name}")
                continue
            
            monthly_prices = []
            for date, row in hist.iterrows():
                monthly_prices.append({
                    "date": date.strftime("%Y-%m-%d"),
                    "close": round(float(row["Close"]), 2),
                    "volume": int(row["Volume"]) if "Volume" in row else 0
                })
            
            all_data[name] = monthly_prices
            print(f"  Got {len(monthly_prices)} months of data")
            
        except Exception as e:
            print(f"  ERROR fetching {name}: {e}")
    
    return all_data

def compute_returns(data):
    """Compute monthly and annual returns from price data."""
    returns_data = {}
    
    for name, prices in data.items():
        if len(prices) < 2:
            continue
        
        monthly_returns = []
        for i in range(1, len(prices)):
            prev_price = prices[i-1]["close"]
            curr_price = prices[i]["close"]
            if prev_price > 0:
                ret = round((curr_price - prev_price) / prev_price * 100, 2)
                monthly_returns.append({
                    "date": prices[i]["date"],
                    "return_pct": ret
                })
        
        # Annual returns (April to March FY)
        annual_returns = []
        fy_groups = {}
        for p in prices:
            date = datetime.strptime(p["date"], "%Y-%m-%d")
            fy = date.year if date.month >= 4 else date.year - 1
            fy_key = f"FY{str(fy+1)[-2:]}"
            if fy_key not in fy_groups:
                fy_groups[fy_key] = {"first": p["close"], "last": p["close"]}
            else:
                fy_groups[fy_key]["last"] = p["close"]
        
        for fy, vals in fy_groups.items():
            if vals["first"] > 0:
                annual_ret = round((vals["last"] - vals["first"]) / vals["first"] * 100, 2)
                annual_returns.append({"fy": fy, "return_pct": annual_ret})
        
        returns_data[name] = {
            "monthly_returns": monthly_returns,
            "annual_returns": annual_returns
        }
    
    return returns_data

def export_to_js(prices, returns):
    """Export all data to a JavaScript file for the dashboard."""
    
    output = {
        "prices": prices,
        "returns": returns,
        "metadata": {
            "start_date": START_DATE,
            "end_date": END_DATE,
            "entities": {
                "icici": {
                    "name": "ICICI Bank",
                    "peers": ["HDFC Bank", "Axis Bank", "Kotak Mahindra Bank"],
                    "category": "Large Private Sector Bank"
                },
                "yesbank": {
                    "name": "Yes Bank",
                    "peers": ["Federal Bank", "RBL Bank", "IDFC First Bank", "Bandhan Bank"],
                    "category": "Mid-sized Private Bank"
                }
            },
            "benchmark": "Nifty Bank",
            "source": "Yahoo Finance via yfinance",
            "fetched_on": datetime.now().strftime("%Y-%m-%d")
        }
    }
    
    js_content = f"// Auto-generated stock price data\n// Source: Yahoo Finance | Period: {START_DATE} to {END_DATE}\n\nconst STOCK_DATA = {json.dumps(output, indent=2)};\n"
    
    import os
    out_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data", "stock_data.js")
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(js_content)
    
    print(f"\nExported to data/stock_data.js")

if __name__ == "__main__":
    print("=" * 60)
    print("FRA Project — Fetching Stock Price Data")
    print("=" * 60)
    
    prices = fetch_monthly_data()
    returns = compute_returns(prices)
    export_to_js(prices, returns)
    
    print("\nDone! Stock data ready.")
